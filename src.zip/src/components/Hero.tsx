"use client";
import { useEffect, useRef, useState } from "react";

/* ─── Particle Canvas Background ───────────────────────── */
function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let animId: number;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const PARTICLE_COUNT = 80;
    type P = { x: number; y: number; vx: number; vy: number; r: number; alpha: number };

    const particles: P[] = Array.from({ length: PARTICLE_COUNT }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      r: Math.random() * 2 + 0.5,
      alpha: Math.random() * 0.5 + 0.1,
    }));

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Connection lines
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(99,102,241,${0.12 * (1 - dist / 120)})`;
            ctx.lineWidth = 1;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      // Particles
      particles.forEach((p) => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(129,140,248,${p.alpha})`;
        ctx.fill();

        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
      });

      animId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
    />
  );
}

/* ─── Animated Text Reveal ──────────────────────────────── */
function TypewriterText({ texts }: { texts: string[] }) {
  const [idx, setIdx] = useState(0);
  const [displayed, setDisplayed] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const target = texts[idx];
    let timeout: ReturnType<typeof setTimeout>;

    if (!deleting && displayed.length < target.length) {
      timeout = setTimeout(() => setDisplayed(target.slice(0, displayed.length + 1)), 80);
    } else if (!deleting && displayed.length === target.length) {
      timeout = setTimeout(() => setDeleting(true), 2000);
    } else if (deleting && displayed.length > 0) {
      timeout = setTimeout(() => setDisplayed(displayed.slice(0, -1)), 40);
    } else if (deleting && displayed.length === 0) {
      setDeleting(false);
      setIdx((i) => (i + 1) % texts.length);
    }
    return () => clearTimeout(timeout);
  }, [displayed, deleting, idx, texts]);

  return (
    <span style={{ color: "#818cf8" }}>
      {displayed}
      <span
        style={{
          display: "inline-block",
          width: 3,
          height: "1em",
          background: "#818cf8",
          marginLeft: 2,
          verticalAlign: "middle",
          animation: "blink 1s step-end infinite",
        }}
      />
    </span>
  );
}

/* ─── Hero Section ──────────────────────────────────────── */
export default function Hero() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setTimeout(() => setMounted(true), 100);
  }, []);

  return (
    <section
      id="home"
      style={{
        position: "relative",
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        overflow: "hidden",
        background: "linear-gradient(135deg, #020209 0%, #05050f 50%, #080818 100%)",
      }}
    >
      <style>{`
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-12px)} }
        @keyframes glow-pulse { 0%,100%{opacity:.3;transform:scale(1)} 50%{opacity:.6;transform:scale(1.08)} }
        @keyframes slide-up { from{opacity:0;transform:translateY(40px)} to{opacity:1;transform:translateY(0)} }
        @keyframes slide-right { from{opacity:0;transform:translateX(40px)} to{opacity:1;transform:translateX(0)} }
        @keyframes orbit { from{transform:rotate(0deg) translateX(70px) rotate(0deg)} to{transform:rotate(360deg) translateX(70px) rotate(-360deg)} }
        @keyframes orbit2 { from{transform:rotate(120deg) translateX(100px) rotate(-120deg)} to{transform:rotate(480deg) translateX(100px) rotate(-480deg)} }
        @keyframes orbit3 { from{transform:rotate(240deg) translateX(130px) rotate(-240deg)} to{transform:rotate(600deg) translateX(130px) rotate(-600deg)} }

        .hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.35rem 0.9rem;
          border-radius: 999px;
          background: rgba(99,102,241,0.12);
          border: 1px solid rgba(99,102,241,0.3);
          font-size: 0.78rem;
          font-weight: 600;
          color: #818cf8;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          margin-bottom: 1.5rem;
          font-family: 'JetBrains Mono', 'Space Mono', monospace;
        }
        .badge-dot {
          width: 6px; height: 6px;
          border-radius: 50%;
          background: #4ade80;
          box-shadow: 0 0 6px #4ade80;
          animation: blink 2s ease-in-out infinite;
        }
        .hero-title {
          font-size: clamp(2.8rem, 6vw, 5rem);
          font-weight: 900;
          line-height: 1.0;
          letter-spacing: -0.04em;
          color: #f1f5f9;
          margin-bottom: 1rem;
          font-family: 'Syne', 'Space Grotesk', sans-serif;
        }
        .hero-title .gradient-text {
          background: linear-gradient(135deg, #818cf8 0%, #38bdf8 50%, #34d399 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        .hero-sub {
          font-size: clamp(1rem, 2.5vw, 1.2rem);
          color: #64748b;
          line-height: 1.7;
          max-width: 520px;
          margin-bottom: 2.5rem;
          font-family: 'Space Grotesk', sans-serif;
        }
        .hero-sub strong { color: #94a3b8; font-weight: 600; }
        .hero-cta-primary {
          position: relative;
          display: inline-flex;
          align-items: center;
          gap: 0.6rem;
          padding: 0.8rem 2rem;
          border-radius: 999px;
          background: linear-gradient(135deg, #6366f1, #4f46e5);
          color: #fff;
          font-weight: 700;
          font-size: 0.92rem;
          border: none;
          cursor: pointer;
          text-decoration: none;
          font-family: 'Space Grotesk', sans-serif;
          letter-spacing: 0.02em;
          transition: all 0.3s ease;
          box-shadow: 0 0 20px rgba(99,102,241,0.4), 0 4px 20px rgba(0,0,0,0.3);
          overflow: hidden;
        }
        .hero-cta-primary::before {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(255,255,255,0.15), transparent);
          opacity: 0;
          transition: opacity 0.3s;
        }
        .hero-cta-primary:hover::before { opacity: 1; }
        .hero-cta-primary:hover {
          box-shadow: 0 0 40px rgba(99,102,241,0.6), 0 8px 30px rgba(0,0,0,0.4);
          transform: translateY(-2px);
        }
        .hero-cta-secondary {
          display: inline-flex;
          align-items: center;
          gap: 0.6rem;
          padding: 0.8rem 2rem;
          border-radius: 999px;
          background: transparent;
          color: #94a3b8;
          font-weight: 600;
          font-size: 0.92rem;
          border: 1px solid rgba(148,163,184,0.2);
          cursor: pointer;
          text-decoration: none;
          font-family: 'Space Grotesk', sans-serif;
          transition: all 0.3s ease;
        }
        .hero-cta-secondary:hover {
          border-color: rgba(99,102,241,0.5);
          color: #c7d2fe;
          background: rgba(99,102,241,0.08);
        }
        .hero-stats {
          display: flex;
          gap: 2rem;
          margin-top: 3rem;
          flex-wrap: wrap;
        }
        .stat-item { display: flex; flex-direction: column; }
        .stat-num {
          font-size: 1.8rem;
          font-weight: 800;
          background: linear-gradient(135deg, #818cf8, #38bdf8);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          font-family: 'Syne', sans-serif;
          line-height: 1;
        }
        .stat-label {
          font-size: 0.75rem;
          color: #475569;
          font-weight: 500;
          margin-top: 0.2rem;
          font-family: 'Space Grotesk', sans-serif;
          letter-spacing: 0.05em;
          text-transform: uppercase;
        }
        .hero-visual {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          flex: 1 1 320px;
        }
        .avatar-glow {
          position: absolute;
          width: 380px; height: 380px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(99,102,241,0.25) 0%, transparent 70%);
          animation: glow-pulse 4s ease-in-out infinite;
        }
        .avatar-ring {
          position: absolute;
          border-radius: 50%;
          border: 1px solid rgba(99,102,241,0.2);
          animation: glow-pulse 6s ease-in-out infinite;
        }
        .avatar-img-wrap {
          position: relative;
          z-index: 2;
          animation: float 6s ease-in-out infinite;
        }
        .avatar-img {
          width: 260px; height: 260px;
          border-radius: 50%;
          object-fit: cover;
          border: 3px solid rgba(99,102,241,0.4);
          box-shadow: 0 0 60px rgba(99,102,241,0.3), 0 30px 80px rgba(0,0,0,0.5);
        }
        .orbit-icon {
          position: absolute;
          width: 40px; height: 40px;
          border-radius: 10px;
          background: rgba(15, 15, 35, 0.9);
          border: 1px solid rgba(99,102,241,0.3);
          display: flex; align-items: center; justify-content: center;
          font-size: 1.2rem;
          box-shadow: 0 4px 20px rgba(0,0,0,0.4), 0 0 10px rgba(99,102,241,0.15);
          z-index: 3;
        }
        .social-links {
          display: flex;
          gap: 0.75rem;
          margin-top: 2rem;
        }
        .social-link {
          width: 38px; height: 38px;
          border-radius: 10px;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.08);
          color: #64748b;
          display: flex; align-items: center; justify-content: center;
          text-decoration: none;
          transition: all 0.2s;
        }
        .social-link:hover {
          background: rgba(99,102,241,0.15);
          border-color: rgba(99,102,241,0.4);
          color: #818cf8;
        }
        @media (max-width: 768px) {
          .hero-inner { flex-direction: column !important; text-align: center; }
          .hero-sub { margin: 0 auto 2.5rem; }
          .hero-badge { margin: 0 auto 1.5rem; }
          .hero-stats { justify-content: center; }
          .social-links { justify-content: center; }
          .hero-btns { justify-content: center; }
          .avatar-glow, .avatar-ring { width: 260px !important; height: 260px !important; }
          .avatar-img { width: 200px !important; height: 200px !important; }
        }
      `}</style>

      {/* Particle background */}
      <ParticleCanvas />

      {/* Gradient orbs */}
      <div style={{ position: "absolute", top: "20%", left: "10%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(99,102,241,0.08) 0%, transparent 70%)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "10%", right: "5%", width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, rgba(56,189,248,0.06) 0%, transparent 70%)", pointerEvents: "none" }} />

      <div
        className="hero-inner"
        style={{
          position: "relative",
          zIndex: 2,
          maxWidth: 1280,
          margin: "0 auto",
          padding: "7rem 2rem 4rem",
          display: "flex",
          alignItems: "center",
          gap: "4rem",
          flexWrap: "wrap",
          width: "100%",
        }}
      >
        {/* Left: Text Content */}
        <div
          style={{
            flex: "1 1 480px",
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.22,1,0.36,1)",
          }}
        >
          <div className="hero-badge">
            <span className="badge-dot" />
            Available for opportunities
          </div>

          <h1 className="hero-title">
            Hi, I'm{" "}
            <span className="gradient-text">Mohamed Ahmed</span>
            <br />
            <TypewriterText
              texts={["Frontend Engineer", "Next.js Developer", "UI Craftsman", "React Specialist"]}
            />
          </h1>

          <p className="hero-sub">
            A dedicated <strong>Frontend Developer</strong> specializing in building{" "}
            <strong>high-performance, responsive</strong> web applications with{" "}
            <strong>Next.js, React & TypeScript</strong>. Currently at{" "}
            <strong>Root Academy</strong> & studying at <strong>Cairo University</strong>.
          </p>

          <div className="hero-btns" style={{ display: "flex", flexWrap: "wrap", gap: "1rem" }}>
            <a href="#contact" className="hero-cta-primary">
              Let's Work Together
              <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                <path d="M5 12h14M12 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </a>
            <a href="#projects" className="hero-cta-secondary">
              View Projects
              <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <rect x="3" y="3" width="7" height="7" rx="1" />
                <rect x="14" y="3" width="7" height="7" rx="1" />
                <rect x="3" y="14" width="7" height="7" rx="1" />
                <rect x="14" y="14" width="7" height="7" rx="1" />
              </svg>
            </a>
          </div>

          <div className="social-links">
            <a href="https://github.com/mvchnccc-oss" target="_blank" rel="noreferrer" className="social-link" aria-label="GitHub">
              <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.164 6.839 9.49.5.09.682-.218.682-.484 0-.236-.009-.866-.013-1.7-2.782.605-3.369-1.343-3.369-1.343-.454-1.155-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.202 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.579.688.481C19.138 20.16 22 16.416 22 12c0-5.523-4.477-10-10-10z" />
              </svg>
            </a>
            <a href="https://www.linkedin.com/in/mohamed-ahmed-423364368" target="_blank" rel="noreferrer" className="social-link" aria-label="LinkedIn">
              <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
              </svg>
            </a>
            <a href="mailto:mvchnccc@gmail.com" className="social-link" aria-label="Email">
              <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </a>
          </div>

          <div className="hero-stats">
            <div className="stat-item">
              <span className="stat-num">2+</span>
              <span className="stat-label">Live Projects</span>
            </div>
            <div className="stat-item">
              <span className="stat-num">8+</span>
              <span className="stat-label">Technologies</span>
            </div>
            <div className="stat-item">
              <span className="stat-num">Cairo</span>
              <span className="stat-label">Egypt 🇪🇬</span>
            </div>
          </div>
        </div>

        {/* Right: Visual */}
        <div
          className="hero-visual"
          style={{
            flex: "0 1 380px",
            minHeight: 380,
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateX(0)" : "translateX(40px)",
            transition: "all 0.9s cubic-bezier(0.22,1,0.36,1) 0.2s",
          }}
        >
          {/* Glow */}
          <div className="avatar-glow" />
          {/* Rings */}
          <div className="avatar-ring" style={{ width: 320, height: 320 }} />
          <div className="avatar-ring" style={{ width: 360, height: 360, opacity: 0.5 }} />

          {/* Orbit icons */}
          <div style={{ position: "absolute", width: "100%", height: "100%", animation: "orbit 8s linear infinite" }}>
            <div className="orbit-icon" style={{ top: "50%", left: "50%", marginTop: -20, marginLeft: -20 }}>⚛️</div>
          </div>
          <div style={{ position: "absolute", width: "100%", height: "100%", animation: "orbit2 12s linear infinite" }}>
            <div className="orbit-icon" style={{ top: "50%", left: "50%", marginTop: -20, marginLeft: -20 }}>▲</div>
          </div>
          <div style={{ position: "absolute", width: "100%", height: "100%", animation: "orbit3 16s linear infinite" }}>
            <div className="orbit-icon" style={{ top: "50%", left: "50%", marginTop: -20, marginLeft: -20 }}>🔷</div>
          </div>

          {/* Avatar */}
          <div className="avatar-img-wrap">
            <img
              src="/Mohamed ahmed.png"
              alt="Mohamed Ahmed Shehata"
              className="avatar-img"
            />
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div style={{
        position: "absolute", bottom: "2rem", left: "50%", transform: "translateX(-50%)",
        display: "flex", flexDirection: "column", alignItems: "center", gap: "0.5rem",
        color: "#334155", fontSize: "0.7rem", fontFamily: "Space Grotesk, sans-serif",
        letterSpacing: "0.1em", textTransform: "uppercase", zIndex: 2,
      }}>
        <span>Scroll</span>
        <div style={{
          width: 24, height: 38, border: "1.5px solid #334155", borderRadius: 12,
          display: "flex", justifyContent: "center", paddingTop: 6,
        }}>
          <div style={{
            width: 3, height: 8, borderRadius: 99, background: "#6366f1",
            animation: "float 1.5s ease-in-out infinite",
          }} />
        </div>
      </div>
    </section>
  );
}
