"use client";
import { useRef, useState, useEffect } from "react";

/* ─── Input Field ────────────────────────────────────────── */
function InputField({
  label, type = "text", placeholder, value, onChange, icon, required,
}: {
  label: string; type?: string; placeholder: string;
  value: string; onChange: (v: string) => void;
  icon: React.ReactNode; required?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
      <label style={{
        fontSize: "0.8rem", fontWeight: 600, color: "#94a3b8",
        fontFamily: "'Space Grotesk', sans-serif",
        letterSpacing: "0.05em", textTransform: "uppercase",
      }}>
        {label} {required && <span style={{ color: "#818cf8" }}>*</span>}
      </label>
      <div style={{ position: "relative" }}>
        <div style={{
          position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)",
          color: focused ? "#818cf8" : "#475569", transition: "color 0.2s",
          pointerEvents: "none", zIndex: 1,
        }}>
          {icon}
        </div>
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            width: "100%", padding: "0.75rem 1rem 0.75rem 2.75rem",
            background: focused ? "rgba(99,102,241,0.06)" : "rgba(255,255,255,0.03)",
            border: `1px solid ${focused ? "rgba(99,102,241,0.5)" : "rgba(255,255,255,0.08)"}`,
            borderRadius: 12, color: "#e2e8f0",
            fontSize: "0.9rem", fontFamily: "'Space Grotesk', sans-serif",
            outline: "none", transition: "all 0.2s",
            boxSizing: "border-box",
            boxShadow: focused ? "0 0 0 3px rgba(99,102,241,0.1)" : "none",
          }}
        />
      </div>
    </div>
  );
}

/* ─── Textarea Field ─────────────────────────────────────── */
function TextareaField({
  label, placeholder, value, onChange, required,
}: {
  label: string; placeholder: string;
  value: string; onChange: (v: string) => void; required?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
      <label style={{
        fontSize: "0.8rem", fontWeight: 600, color: "#94a3b8",
        fontFamily: "'Space Grotesk', sans-serif",
        letterSpacing: "0.05em", textTransform: "uppercase",
      }}>
        {label} {required && <span style={{ color: "#818cf8" }}>*</span>}
      </label>
      <textarea
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        rows={5}
        style={{
          width: "100%", padding: "0.75rem 1rem",
          background: focused ? "rgba(99,102,241,0.06)" : "rgba(255,255,255,0.03)",
          border: `1px solid ${focused ? "rgba(99,102,241,0.5)" : "rgba(255,255,255,0.08)"}`,
          borderRadius: 12, color: "#e2e8f0",
          fontSize: "0.9rem", fontFamily: "'Space Grotesk', sans-serif",
          outline: "none", transition: "all 0.2s", resize: "vertical",
          boxSizing: "border-box",
          boxShadow: focused ? "0 0 0 3px rgba(99,102,241,0.1)" : "none",
        }}
      />
    </div>
  );
}

/* ─── Contact Info Card ──────────────────────────────────── */
function ContactInfoCard({
  icon, label, value, href,
}: {
  icon: React.ReactNode; label: string; value: string; href?: string;
}) {
  const [hov, setHov] = useState(false);
  const content = (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: "flex", alignItems: "center", gap: "1rem",
        padding: "1rem 1.25rem", borderRadius: 14,
        background: hov ? "rgba(99,102,241,0.08)" : "rgba(255,255,255,0.03)",
        border: `1px solid ${hov ? "rgba(99,102,241,0.3)" : "rgba(255,255,255,0.06)"}`,
        transition: "all 0.2s", cursor: href ? "pointer" : "default",
        textDecoration: "none",
      }}
    >
      <div style={{
        width: 40, height: 40, borderRadius: 10,
        background: "rgba(99,102,241,0.12)",
        border: "1px solid rgba(99,102,241,0.2)",
        display: "flex", alignItems: "center", justifyContent: "center",
        color: "#818cf8", flexShrink: 0,
        boxShadow: hov ? "0 0 12px rgba(99,102,241,0.3)" : "none",
        transition: "box-shadow 0.2s",
      }}>
        {icon}
      </div>
      <div>
        <div style={{ fontSize: "0.72rem", color: "#475569", fontWeight: 600, fontFamily: "'Space Grotesk', sans-serif", textTransform: "uppercase", letterSpacing: "0.06em" }}>
          {label}
        </div>
        <div style={{ fontSize: "0.9rem", color: hov ? "#c7d2fe" : "#94a3b8", fontFamily: "'Space Grotesk', sans-serif", fontWeight: 500, transition: "color 0.2s" }}>
          {value}
        </div>
      </div>
    </div>
  );

  return href ? <a href={href} style={{ textDecoration: "none" }}>{content}</a> : content;
}

/* ─── Contact Section ────────────────────────────────────── */
export default function Contact() {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setStatus("sending");
    // Simulate async submit — wire to Formspree / EmailJS / API route
    await new Promise((r) => setTimeout(r, 1800));
    setStatus("sent");
    setTimeout(() => {
      setStatus("idle");
      setForm({ name: "", email: "", subject: "", message: "" });
    }, 4000);
  };

  const iconUser = (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
  const iconMail = (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
  const iconTag = (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A2 2 0 013 12V7a4 4 0 014-4z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );

  return (
    <section id="contact" style={{ padding: "7rem 2rem", background: "#030310", color: "#e2e8f0" }}>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        .section-label-pill {
          display: inline-flex; align-items: center; gap: 0.5rem;
          padding: 0.3rem 0.9rem; border-radius: 999px;
          background: rgba(99,102,241,0.1); border: 1px solid rgba(99,102,241,0.25);
          color: #818cf8; font-size: 0.75rem; font-weight: 700;
          letter-spacing: 0.1em; text-transform: uppercase;
          font-family: 'Space Grotesk', sans-serif; margin-bottom: 1rem;
        }
        @media (max-width: 900px) {
          .contact-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>

      <div ref={ref} style={{ maxWidth: 1280, margin: "0 auto" }}>

        {/* Header */}
        <div style={{
          textAlign: "center", marginBottom: "4rem",
          opacity: visible ? 1 : 0,
          transform: visible ? "translateY(0)" : "translateY(20px)",
          transition: "all 0.6s ease",
        }}>
          <div className="section-label-pill">Get In Touch</div>
          <h2 style={{
            fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 900,
            fontFamily: "'Syne', sans-serif", letterSpacing: "-0.04em",
            color: "#f1f5f9", marginBottom: "1rem",
          }}>
            Let's build something{" "}
            <span style={{ background: "linear-gradient(135deg,#818cf8,#38bdf8)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              amazing
            </span>
          </h2>
          <p style={{
            color: "#475569", maxWidth: 520, margin: "0 auto",
            fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.7, fontSize: "0.95rem",
          }}>
            Have a project in mind or just want to say hello? My inbox is always open. I'll get back to you as soon as possible.
          </p>
        </div>

        {/* Two-column grid */}
        <div className="contact-grid" style={{
          display: "grid", gridTemplateColumns: "1fr 1.6fr", gap: "2rem",
          opacity: visible ? 1 : 0,
          transition: "all 0.6s ease 0.2s",
        }}>

          {/* Left: Info */}
          <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
            {/* Availability card */}
            <div style={{
              padding: "1.5rem", borderRadius: 16,
              background: "rgba(99,102,241,0.07)",
              border: "1px solid rgba(99,102,241,0.2)",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.75rem" }}>
                <div style={{
                  width: 8, height: 8, borderRadius: "50%",
                  background: "#4ade80", boxShadow: "0 0 8px #4ade80",
                  animation: "spin 0s", // static pulse handled by blink in hero
                }} />
                <span style={{ fontSize: "0.8rem", color: "#4ade80", fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif", textTransform: "uppercase", letterSpacing: "0.06em" }}>
                  Available for Work
                </span>
              </div>
              <p style={{ color: "#64748b", fontSize: "0.875rem", lineHeight: 1.7, fontFamily: "'Space Grotesk', sans-serif" }}>
                Currently open to <strong style={{ color: "#94a3b8" }}>junior/mid frontend roles</strong>, freelance projects, and internship opportunities.
              </p>
            </div>

            {/* Contact info */}
            <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
              <ContactInfoCard
                icon={iconMail}
                label="Email"
                value="mvchnccc@gmail.com"
                href="mailto:mvchnccc@gmail.com"
              />
              <ContactInfoCard
                icon={
                  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 10.8 19.79 19.79 0 01.28 2.22 2 2 0 012.28 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006.16 6.16l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                }
                label="Phone"
                value="+20 112 903 3610"
                href="tel:+201129033610"
              />
              <ContactInfoCard
                icon={
                  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1118 0z" strokeLinecap="round" strokeLinejoin="round" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                }
                label="Location"
                value="Cairo, Egypt 🇪🇬"
              />
            </div>

            {/* Social row */}
            <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
              {[
                {
                  label: "GitHub",
                  href: "https://github.com/mvchnccc-oss",
                  icon: (
                    <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.164 6.839 9.49.5.09.682-.218.682-.484 0-.236-.009-.866-.013-1.7-2.782.605-3.369-1.343-3.369-1.343-.454-1.155-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.202 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.579.688.481C19.138 20.16 22 16.416 22 12c0-5.523-4.477-10-10-10z" />
                    </svg>
                  ),
                },
                {
                  label: "LinkedIn",
                  href: "https://www.linkedin.com/in/mohamed-ahmed-423364368",
                  icon: (
                    <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                    </svg>
                  ),
                },
              ].map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    display: "inline-flex", alignItems: "center", gap: "0.5rem",
                    padding: "0.55rem 1rem", borderRadius: 10,
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.07)",
                    color: "#64748b", textDecoration: "none",
                    fontSize: "0.82rem", fontWeight: 600,
                    fontFamily: "'Space Grotesk', sans-serif",
                    transition: "all 0.2s",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = "rgba(99,102,241,0.4)";
                    e.currentTarget.style.color = "#818cf8";
                    e.currentTarget.style.background = "rgba(99,102,241,0.08)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = "rgba(255,255,255,0.07)";
                    e.currentTarget.style.color = "#64748b";
                    e.currentTarget.style.background = "rgba(255,255,255,0.03)";
                  }}
                >
                  {s.icon}
                  {s.label}
                </a>
              ))}
            </div>
          </div>

          {/* Right: Form */}
          <div style={{
            background: "rgba(8, 8, 22, 0.7)",
            border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 20, padding: "2rem",
            backdropFilter: "blur(12px)",
            boxShadow: "0 20px 60px rgba(0,0,0,0.3)",
            position: "relative", overflow: "hidden",
          }}>
            {/* Glow corner */}
            <div style={{
              position: "absolute", top: 0, right: 0, width: 200, height: 200,
              background: "radial-gradient(circle, rgba(99,102,241,0.08) 0%, transparent 70%)",
              pointerEvents: "none",
            }} />

            {status === "sent" ? (
              <div style={{
                display: "flex", flexDirection: "column", alignItems: "center",
                justifyContent: "center", textAlign: "center", padding: "3rem 1rem",
                gap: "1rem",
              }}>
                <div style={{
                  width: 64, height: 64, borderRadius: "50%",
                  background: "rgba(74,222,128,0.12)",
                  border: "1px solid rgba(74,222,128,0.3)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "1.8rem",
                }}>
                  ✅
                </div>
                <h3 style={{ fontSize: "1.3rem", fontWeight: 800, color: "#f1f5f9", fontFamily: "'Syne', sans-serif" }}>
                  Message Sent!
                </h3>
                <p style={{ color: "#64748b", fontSize: "0.9rem", fontFamily: "'Space Grotesk', sans-serif" }}>
                  Thanks for reaching out! I'll get back to you very soon.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                  <InputField
                    label="Your Name"
                    placeholder="Mohamed Ahmed"
                    value={form.name}
                    onChange={(v) => setForm((f) => ({ ...f, name: v }))}
                    icon={iconUser}
                    required
                  />
                  <InputField
                    label="Email"
                    type="email"
                    placeholder="you@example.com"
                    value={form.email}
                    onChange={(v) => setForm((f) => ({ ...f, email: v }))}
                    icon={iconMail}
                    required
                  />
                </div>
                <InputField
                  label="Subject"
                  placeholder="Project inquiry, collaboration..."
                  value={form.subject}
                  onChange={(v) => setForm((f) => ({ ...f, subject: v }))}
                  icon={iconTag}
                />
                <TextareaField
                  label="Message"
                  placeholder="Tell me about your project or idea..."
                  value={form.message}
                  onChange={(v) => setForm((f) => ({ ...f, message: v }))}
                  required
                />

                <button
                  type="submit"
                  disabled={status === "sending"}
                  style={{
                    display: "flex", alignItems: "center", justifyContent: "center",
                    gap: "0.6rem", padding: "0.85rem 2rem",
                    borderRadius: 999,
                    background: status === "sending"
                      ? "rgba(99,102,241,0.5)"
                      : "linear-gradient(135deg, #6366f1, #4f46e5)",
                    color: "#fff", fontWeight: 700, fontSize: "0.9rem",
                    border: "none", cursor: status === "sending" ? "not-allowed" : "pointer",
                    fontFamily: "'Space Grotesk', sans-serif",
                    boxShadow: "0 0 24px rgba(99,102,241,0.35)",
                    transition: "all 0.3s", width: "100%",
                  }}
                >
                  {status === "sending" ? (
                    <>
                      <svg style={{ animation: "spin 1s linear infinite" }} width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                        <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" strokeLinecap="round" />
                      </svg>
                      Sending...
                    </>
                  ) : (
                    <>
                      Send Message
                      <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                        <path d="M22 2L11 13M22 2L15 22l-4-9-9-4 20-7z" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </>
                  )}
                </button>

                <p style={{ textAlign: "center", fontSize: "0.75rem", color: "#334155", fontFamily: "'Space Grotesk', sans-serif" }}>
                  No spam, ever. I respect your privacy.
                </p>
              </form>
            )}
          </div>
        </div>

      </div>
    </section>
  );
}
